helloworld_rx
==========================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/helloworld_rx.cpp
    :caption: examples_pico/helloworld_rx.cpp
    :linenos:
